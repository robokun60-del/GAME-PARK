/* 反射神経チャレンジ */
(function () {
  'use strict';
  var ROUNDS = 5, TIMEOUT = 2000, MAX_PTS = 1000, MISS_PENALTY = 100;

  window.GP.registerGame('reaction', function (root, api) {
    root.innerHTML =
      '<div class="rx">' +
        '<div class="hud">' +
          '<div><span>ラウンド</span><b data-round>0 / ' + ROUNDS + '</b></div>' +
          '<div><span>直前の反応</span><b data-last>—</b></div>' +
          '<div><span>スコア</span><b data-score>0</b></div>' +
        '</div>' +
        '<div class="rx-arena" data-arena>' +
          '<div class="rx-msg" data-msg role="status" aria-live="polite"></div>' +
          '<button type="button" class="rx-target" data-target hidden aria-label="ターゲット"></button>' +
        '</div>' +
      '</div>';

    var $ = function (s) { return root.querySelector(s); };
    var arena = $('[data-arena]'), target = $('[data-target]'), msg = $('[data-msg]');
    var elRound = $('[data-round]'), elLast = $('[data-last]'), elScore = $('[data-score]');
    var state = 'idle', timer = null, t0 = 0, round = 0, score = 0, misses = 0, times = [];

    function clear() { if (timer) { clearTimeout(timer); timer = null; } }
    function hud() {
      elRound.textContent = round + ' / ' + ROUNDS;
      elScore.textContent = score.toLocaleString('ja-JP');
    }
    function showIdle() {
      state = 'idle';
      msg.innerHTML =
        '<p class="rx-big">準備はいい?</p>' +
        '<p class="rx-sub">ターゲットが現れたらすぐタップ!</p>' +
        '<button type="button" class="btn btn-primary btn-lg" data-start>スタート</button>';
    }
    function start() {
      clear();
      api.recordPlay();
      round = 0; score = 0; misses = 0; times = [];
      elLast.textContent = '—';
      nextRound();
    }
    function nextRound() {
      round += 1;
      state = 'waiting';
      hud();
      msg.innerHTML = '<p class="rx-wait">よーい…</p>';
      timer = setTimeout(showTarget, 900 + Math.random() * 1800);
    }
    function showTarget() {
      var size = 84, pad = 12;
      var w = Math.max(arena.clientWidth - size - pad * 2, 0);
      var h = Math.max(arena.clientHeight - size - pad * 2, 0);
      target.style.left = pad + Math.random() * w + 'px';
      target.style.top = pad + Math.random() * h + 'px';
      msg.innerHTML = '';
      target.hidden = false;
      state = 'target';
      t0 = performance.now();
      timer = setTimeout(function () { endRound(null); }, TIMEOUT);
    }
    function endRound(ms) {
      clear();
      target.hidden = true;
      state = 'between';
      times.push(ms);
      if (ms === null) {
        elLast.textContent = '時間切れ';
        msg.innerHTML = '<p class="rx-flash is-bad">時間切れ</p>';
      } else {
        var pts = Math.max(0, MAX_PTS - ms);
        score += pts;
        elLast.textContent = ms + ' ms';
        msg.innerHTML = '<p class="rx-flash">' + ms + ' ms<small>+' + pts + '</small></p>';
      }
      hud();
      timer = setTimeout(round < ROUNDS ? nextRound : finish, 800);
    }
    function hit(e) {
      if (state !== 'target') return;
      e.preventDefault();
      e.stopPropagation();
      endRound(Math.round(performance.now() - t0));
    }
    function miss(e) {
      if (state !== 'target' || e.target === target) return;
      misses += 1;
      score = Math.max(0, score - MISS_PENALTY);
      hud();
      arena.classList.remove('is-miss');
      void arena.offsetWidth;
      arena.classList.add('is-miss');
    }
    function finish() {
      state = 'done';
      var ok = times.filter(function (t) { return t !== null; });
      var avg = ok.length ? Math.round(ok.reduce(function (a, b) { return a + b; }, 0) / ok.length) : null;
      var res = score > 0 ? api.submitScore(score) : { isBest: false, best: api.getBest() };
      msg.innerHTML =
        '<div class="result">' +
          (res.isBest ? '<p class="result-badge">ベストスコア更新!</p>' : '') +
          '<p class="result-label">スコア</p>' +
          '<p class="result-value">' + score.toLocaleString('ja-JP') + '<small>点</small></p>' +
          '<ul class="result-meta">' +
            '<li>平均反応 <b>' + (avg === null ? '—' : avg + ' ms') + '</b></li>' +
            '<li>ミス <b>' + misses + '回</b></li>' +
            '<li>ベスト <b>' + (res.best === null ? '—' : res.best.toLocaleString('ja-JP') + '点') + '</b></li>' +
          '</ul>' +
          '<ol class="rx-rounds">' + times.map(function (t) {
            return '<li>' + (t === null ? '×' : t + '<small>ms</small>') + '</li>';
          }).join('') + '</ol>' +
          '<button type="button" class="btn btn-primary btn-lg" data-start>もう一度</button>' +
        '</div>';
    }

    target.addEventListener('pointerdown', hit);
    target.addEventListener('click', hit); /* キーボード操作用 */
    arena.addEventListener('pointerdown', miss);
    msg.addEventListener('click', function (e) {
      if (e.target.closest('[data-start]')) start();
    });

    showIdle();
    return function unmount() { clear(); state = 'idle'; };
  });
})();
