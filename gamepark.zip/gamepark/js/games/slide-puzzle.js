/* スライドパズル (3×3) */
(function () {
  'use strict';
  var N = 3, SIZE = N * N;

  window.GP.registerGame('slide-puzzle', function (root, api) {
    var tilesHtml = '';
    for (var v = 1; v < SIZE; v++) {
      tilesHtml += '<button type="button" class="sp-tile" data-value="' + v + '"><span>' + v + '</span></button>';
    }
    root.innerHTML =
      '<div class="sp">' +
        '<div class="hud">' +
          '<div><span>移動回数</span><b data-moves>0</b></div>' +
          '<div class="hud-action"><button type="button" class="btn btn-ghost" data-shuffle>シャッフル</button></div>' +
        '</div>' +
        '<div class="sp-board" data-board>' + tilesHtml + '</div>' +
        '<p class="sp-status" data-status role="status" aria-live="polite"></p>' +
        '<div class="sp-clear" data-clear hidden></div>' +
      '</div>';

    var $ = function (s) { return root.querySelector(s); };
    var boardEl = $('[data-board]'), elMoves = $('[data-moves]'), statusEl = $('[data-status]'), clearEl = $('[data-clear]');
    var tiles = {};
    Array.prototype.forEach.call(boardEl.querySelectorAll('.sp-tile'), function (t) { tiles[t.dataset.value] = t; });
    var board = [], moves = 0, solved = false;

    function neighbors(i) {
      var r = Math.floor(i / N), c = i % N, out = [];
      if (r > 0) out.push(i - N);
      if (r < N - 1) out.push(i + N);
      if (c > 0) out.push(i - 1);
      if (c < N - 1) out.push(i + 1);
      return out;
    }
    function isSolved() {
      for (var i = 0; i < SIZE - 1; i++) if (board[i] !== i + 1) return false;
      return true;
    }
    function render() {
      var blank = board.indexOf(0), near = neighbors(blank);
      board.forEach(function (val, i) {
        if (!val) return;
        var t = tiles[val];
        t.style.transform = 'translate(' + (i % N) * 100 + '%,' + Math.floor(i / N) * 100 + '%)';
        t.dataset.index = i;
        t.disabled = solved;
        t.classList.toggle('is-movable', !solved && near.indexOf(i) !== -1);
        t.classList.toggle('is-home', val === i + 1);
        t.setAttribute('aria-label', val + (near.indexOf(i) !== -1 ? '(動かせます)' : ''));
      });
      elMoves.textContent = moves;
      boardEl.classList.toggle('is-solved', solved);
    }
    /* 完成形からランダムに動かすので、必ず解ける配置になります */
    function shuffle() {
      do {
        board = [];
        for (var i = 1; i < SIZE; i++) board.push(i);
        board.push(0);
        var blank = SIZE - 1, prev = -1;
        for (var k = 0; k < 160; k++) {
          var opts = neighbors(blank).filter(function (x) { return x !== prev; });
          var next = opts[Math.floor(Math.random() * opts.length)];
          board[blank] = board[next]; board[next] = 0;
          prev = blank; blank = next;
        }
      } while (isSolved());
      moves = 0; solved = false;
      clearEl.hidden = true;
      statusEl.textContent = '空きマスの隣のタイルをタップ';
      render();
    }
    function moveIndex(i) {
      if (solved || i < 0 || i >= SIZE) return;
      var blank = board.indexOf(0);
      if (neighbors(blank).indexOf(i) === -1) return;
      if (moves === 0) api.recordPlay();
      board[blank] = board[i]; board[i] = 0;
      moves += 1;
      if (isSolved()) { solved = true; render(); return win(); }
      render();
    }
    function win() {
      var res = api.submitScore(moves);
      statusEl.textContent = '';
      clearEl.hidden = false;
      clearEl.innerHTML =
        '<div class="result">' +
          '<p class="result-badge">' + (res.isBest ? '自己ベスト更新!' : 'クリア!') + '</p>' +
          '<p class="result-label">完成までの手数</p>' +
          '<p class="result-value">' + moves + '<small>手</small></p>' +
          '<ul class="result-meta"><li>最少手数 <b>' + res.best + '手</b></li></ul>' +
          '<button type="button" class="btn btn-primary btn-lg" data-again>もう一度遊ぶ</button>' +
        '</div>';
    }

    boardEl.addEventListener('click', function (e) {
      var t = e.target.closest('.sp-tile');
      if (t) moveIndex(Number(t.dataset.index));
    });
    root.addEventListener('keydown', function (e) {
      var blank = board.indexOf(0), r = Math.floor(blank / N), c = blank % N, i = -1;
      if (e.key === 'ArrowUp' && r < N - 1) i = blank + N;
      else if (e.key === 'ArrowDown' && r > 0) i = blank - N;
      else if (e.key === 'ArrowLeft' && c < N - 1) i = blank + 1;
      else if (e.key === 'ArrowRight' && c > 0) i = blank - 1;
      else return;
      e.preventDefault();
      moveIndex(i);
    });
    $('[data-shuffle]').addEventListener('click', shuffle);
    clearEl.addEventListener('click', function (e) {
      if (e.target.closest('[data-again]')) shuffle();
    });
    shuffle();
  });
})();
