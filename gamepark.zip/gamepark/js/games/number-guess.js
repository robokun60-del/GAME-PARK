/* 数字当てゲーム */
(function () {
  'use strict';
  var MIN = 1, MAX = 100;

  window.GP.registerGame('number-guess', function (root, api) {
    root.innerHTML =
      '<div class="ng">' +
        '<div class="hud">' +
          '<div><span>挑戦回数</span><b data-tries>0</b></div>' +
          '<div><span>残りの範囲</span><b data-range></b></div>' +
        '</div>' +
        '<div class="ng-panel" data-play>' +
          '<p class="ng-hint" data-hint role="status" aria-live="polite"></p>' +
          '<form class="ng-form" data-form novalidate>' +
            '<input type="number" inputmode="numeric" pattern="[0-9]*" min="' + MIN + '" max="' + MAX + '" data-input aria-label="予想する数字" placeholder="?">' +
            '<button type="submit" class="btn btn-primary btn-lg">判定する</button>' +
          '</form>' +
          '<ol class="ng-history" data-history aria-label="これまでの予想"></ol>' +
        '</div>' +
        '<div class="ng-panel" data-clear hidden></div>' +
      '</div>';

    var $ = function (s) { return root.querySelector(s); };
    var play = $('[data-play]'), clearEl = $('[data-clear]'), hint = $('[data-hint]');
    var form = $('[data-form]'), input = $('[data-input]'), historyEl = $('[data-history]');
    var elTries = $('[data-tries]'), elRange = $('[data-range]');
    var answer, tries, lo, hi;

    function setHint(text, cls) {
      hint.textContent = text;
      hint.className = 'ng-hint' + (cls ? ' ' + cls : '');
    }
    function hud() {
      elTries.textContent = tries;
      elRange.textContent = lo + ' 〜 ' + hi;
    }
    function reset() {
      answer = MIN + Math.floor(Math.random() * (MAX - MIN + 1));
      tries = 0; lo = MIN; hi = MAX;
      historyEl.innerHTML = '';
      input.value = '';
      clearEl.hidden = true;
      play.hidden = false;
      setHint(MIN + '〜' + MAX + ' の数字を当ててください');
      hud();
    }
    function guess(e) {
      e.preventDefault();
      var raw = input.value.trim();
      var n = Number(raw);
      if (raw === '' || !Number.isInteger(n) || n < MIN || n > MAX) {
        setHint(MIN + '〜' + MAX + ' の整数を入力してください', 'is-warn');
        return;
      }
      if (tries === 0) api.recordPlay();
      tries += 1;
      if (n === answer) { hud(); return win(); }
      var up = n < answer;
      if (up) lo = Math.max(lo, n + 1); else hi = Math.min(hi, n - 1);
      setHint(n + ' より' + (up ? '大きい ↑' : '小さい ↓'), up ? 'is-up' : 'is-down');
      var li = document.createElement('li');
      li.className = up ? 'is-up' : 'is-down';
      li.textContent = n + (up ? ' ↑' : ' ↓');
      historyEl.insertBefore(li, historyEl.firstChild);
      hud();
      input.value = '';
      input.focus();
    }
    function win() {
      var res = api.submitScore(tries);
      play.hidden = true;
      clearEl.hidden = false;
      clearEl.innerHTML =
        '<div class="result">' +
          '<p class="result-badge">' + (res.isBest ? '自己ベスト更新!' : 'クリア!') + '</p>' +
          '<p class="result-label">正解は</p>' +
          '<p class="result-value">' + answer + '</p>' +
          '<ul class="result-meta">' +
            '<li>挑戦回数 <b>' + tries + '回</b></li>' +
            '<li>最少回数 <b>' + res.best + '回</b></li>' +
          '</ul>' +
          '<button type="button" class="btn btn-primary btn-lg" data-again>もう一度遊ぶ</button>' +
        '</div>';
      clearEl.querySelector('[data-again]').focus();
    }

    form.addEventListener('submit', guess);
    clearEl.addEventListener('click', function (e) {
      if (e.target.closest('[data-again]')) reset();
    });
    reset();
  });
})();
